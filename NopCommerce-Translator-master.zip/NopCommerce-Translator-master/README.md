# NopCommerce-Translator
Translate NopCpmmerce language file to any language with Google Translate

Based on: https://github.com/Marjani/Google-Translator
